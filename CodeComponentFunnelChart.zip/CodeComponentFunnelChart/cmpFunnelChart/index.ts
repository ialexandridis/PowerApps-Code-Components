import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as d3 from 'd3';

interface DataItem {
    stage: string;
    value: number;
}

export class cmpFunnelChart implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private container: HTMLDivElement;
    private labelData: string[] = [];
    private valueData: number[] = [];
    private chartTitle: string;
    private chartTextsSize: number;
    private titleSize: number;
    private chartValuesSize: number;

    private svgWidth: number = 500;
    private svgHeight: number = 400;
    private defaultColors = ['#0072BD'];

    private maxLabelWidth: number;


    constructor() { }

    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this.container = container;
        this.drawChart(context);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        while (this.container.firstChild) {
            this.container.removeChild(this.container.firstChild);
        }

        if (context.parameters.chartHeight) {
            this.svgHeight = context.parameters.chartHeight.raw || this.svgHeight;
        }
        if (context.parameters.chartWidth) {
            this.svgWidth = context.parameters.chartWidth.raw || this.svgWidth;
        }

        if (context.parameters.chartTitle) {
            this.chartTitle = context.parameters.chartTitle.raw || '';
        }

        if (context.parameters.titleSize) {
            this.titleSize = context.parameters.titleSize.raw || 16;
        }
        if (context.parameters.chartTextsSize) {
            this.chartTextsSize = context.parameters.chartTextsSize.raw || 12;
        }
        if (context.parameters.chartValuesSize) {
            this.chartValuesSize = context.parameters.chartValuesSize.raw || 14;
        }

        this.labelData = context.parameters.labelData.raw?.split(',') || [];
        this.valueData = context.parameters.valueData.raw?.split(',').map(Number) || [];

        this.drawChart(context);
    }

    private drawChart(context: ComponentFramework.Context<IInputs>): void {
        if (!this.container || this.labelData.length === 0 || this.labelData.length !== this.valueData.length) {
            return;
        }

        const maxLabelWidth = this.calculateMaxLabelWidth();


        const margin = { top: 30 + this.titleSize , right: 20, bottom: 50, left: maxLabelWidth + 25 };
        const width = this.svgWidth - margin.left - margin.right;
        const height = this.svgHeight - margin.top - margin.bottom;

        const colorScale = this.getColorScale(context); // Get the color scale based on user preferences


        const svg = d3.select(this.container)
            .append('svg')
            .attr('width', this.svgWidth)
            .attr('height', this.svgHeight)
            .append('g')
            .attr('transform', `translate(${margin.left}, ${margin.top})`);

        // Add chart title
        svg.append('text')
            .attr('x', (this.svgWidth - margin.left - margin.right) / 2)
            .attr('y', -margin.top / 2 + 10)
            .attr('text-anchor', 'middle')
            .style('font-size', this.titleSize)
            .text(this.chartTitle);

        const xScale = d3.scaleLinear()
            .domain([0, d3.max(this.valueData) as number])
            .range([0, width]);

        const barHeight = height / this.labelData.length;
        const gap = 10;
        const lineTextHeight = this.chartTextsSize*1.3;

        // Draw the bars
        svg.selectAll('rect')
            .data(this.valueData)
            .enter()
            .append('rect')
            .attr('x', (d) => (width - xScale(d) as number) / 2) // Center-align bars
            .attr('y', (d, i) => i * (barHeight + gap))
            .attr('width', (d) => xScale(d) as number)
            .attr('height', barHeight)
            .attr('fill', (d, i) => colorScale(i.toString())); // Set the fill color based on the color scale

            // Label on the left of the bars with up to 4 rows for long text, breaking at space characters
            svg.selectAll('.label')
                .data(this.labelData)
                .enter()
                .append('text')
                .attr('class', 'label')
                .attr('x', -15) // Offset labels to the left
                .attr('y', (d, i) => i * (barHeight + gap) + gap)
                .each(function(d) {
                    if (d.length > 15) {
                        const labelLines = d3.select(this);
                        const lines = [];
                        let lineCount = 0;

                        while (d.length > 0 && lineCount < barHeight/lineTextHeight) {
                            const breakIndex = Math.min(35, d.length);
                            const line = d.substr(0, breakIndex);

                            if (d.length > breakIndex) {
                                const spaceIndex = line.lastIndexOf(' ');
                                if (spaceIndex !== -1) {
                                    lines.push(line.substr(0, spaceIndex));
                                    d = d.substr(spaceIndex + 1);
                                } else {
                                    lines.push(line);
                                    d = d.substr(breakIndex);
                                }
                            } else {
                                lines.push(line);
                                d = '';
                            }
                            lineCount++;
                        }

                        lines.forEach((line, index) => {
                            labelLines.append('tspan')
                                .attr('x', -15)
                                .attr('dy', index === 0 ? index + 'em' : '1.2em') // Adjust the spacing as needed
                                .text(line);

                            
                        });
                    } else {
                        d3.select(this).text(d);
                    }
                })
                .attr('alignment-baseline', 'middle')
                .style('font-size', this.chartTextsSize)
                .attr('text-anchor', 'end'); // Align labels to the end (right) of the text box

           // Display values inside each bar
            svg.selectAll('.bar-label')
                .data(this.valueData)
                .enter()
                .append('text')
                .attr('class', 'bar-label')
                .attr('x', (d) => (width - xScale(d) as number) / 2 + xScale(d) / 2) // Position values in the middle
                .attr('y', (d, i) => i * (barHeight + gap) + (barHeight / 2))
                .text((d) => this.formatNumber(d))  // Use the formatNumber method to format the number
                .attr('alignment-baseline', 'middle')
                .style('font-size', this.chartValuesSize)
                .style('font-weight', 600)
                .attr('text-anchor', 'middle');

    }

    private calculateMaxLabelWidth(): number {
        const dummyText = this.container.appendChild(document.createElement('div'));
        dummyText.style.position = 'absolute';
        dummyText.style.opacity = '0';
        dummyText.style.font = `${this.chartTextsSize}px sans-serif`;
    
        let maxLabelWidth = 0;
    
        this.labelData.forEach((label) => {
            const lines = this.wrapText(label, 35); // Adjust the line length as needed
            lines.forEach((line) => {
                dummyText.textContent = line;
                maxLabelWidth = Math.max(maxLabelWidth, dummyText.clientWidth);
            });
        });
    
        this.container.removeChild(dummyText);
    
        return maxLabelWidth;
    }

    private wrapText(text: string, maxChars: number): string[] {
        const words = text.split(' ');
        const lines: string[] = [];
        let currentLine = '';
    
        words.forEach((word) => {
            if ((currentLine + word).length <= maxChars) {
                currentLine += (currentLine === '' ? '' : ' ') + word;
            } else {
                lines.push(currentLine);
                currentLine = word;
            }
        });
    
        if (currentLine !== '') {
            lines.push(currentLine);
        }
    
        return lines;
    }

    private formatNumber(n: number | { valueOf(): number }): string {
        const value = typeof n === 'number' ? n : n.valueOf();
        if (value >= 1e12) {
            return (value / 1e12).toFixed(1).replace(/\.0$/, '') + 'T';
        }
        if (value >= 1e9) {
            return (value / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
        }
        if (value >= 1e6) {
            return (value / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
        }
        if (value >= 1e3) {
            return (value / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
        }
        return value.toString();
    }

    private colorPalettes: { [key: string]: string[] } = {
        Light_Green: ['#94BC5D'],
        Yellow: ['#F4D470'],
        Purple: ['#A48BC1'],
        Blue_Gray: ['#5C96A5'],
        Gold: ['#F5C767'],
        Dark_Grayish_Purple: ['#76677B'],
        Pale_Yellow: ['#DBD588'],
        Pink: ['#DC9BB0'],
        Light_Blue: ['#88C9DB'],
        Teal: ['#8DD3C7'],
        Cream: ['#FFFFB3'],
        Steel_Blue: ['#80B1D3'],
        // ... Add more palettes as needed
    };

    private getColorScale(context: ComponentFramework.Context<IInputs>): d3.ScaleOrdinal<string, string> {
        const paletteKey = context.parameters.ColorPalettePreference.raw;
        const colorPalette = this.colorPalettes[paletteKey as keyof typeof this.colorPalettes] || this.defaultColors;
    
        return d3.scaleOrdinal<string>()
            .domain(['value1'])
            .range(colorPalette);
    }
    

    public getOutputs(): IOutputs {
        return {};
    }

    public destroy(): void { }
}
