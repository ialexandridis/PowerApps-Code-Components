/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    chartHeight: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartWidth: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTitle: ComponentFramework.PropertyTypes.StringProperty;
    labelData: ComponentFramework.PropertyTypes.StringProperty;
    valueData: ComponentFramework.PropertyTypes.StringProperty;
    titleSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTextsSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartValuesSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    ColorPalettePreference: ComponentFramework.PropertyTypes.EnumProperty<"Light_Green" | "Yellow" | "Purple" | "Blue_Gray" | "Gold" | "Dark_Grayish_Purple" | "Pale_Yellow" | "Pink" | "Light_Blue" | "Teal" | "Cream" | "Steel_Blue">;
}
export interface IOutputs {
    chartHeight?: number;
    chartWidth?: number;
    chartTitle?: string;
    titleSize?: number;
    chartTextsSize?: number;
    chartValuesSize?: number;
}
