/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    ColorPalettePreference: ComponentFramework.PropertyTypes.EnumProperty<"colorSet1" | "colorSet2" | "colorSet3" | "colorSet4" | "colorSet5">;
    chartWidth: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartHeight: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTitleText: ComponentFramework.PropertyTypes.StringProperty;
    xAxisData: ComponentFramework.PropertyTypes.StringProperty;
    lineValues: ComponentFramework.PropertyTypes.StringProperty;
    barValues: ComponentFramework.PropertyTypes.StringProperty;
    lineLegendText: ComponentFramework.PropertyTypes.StringProperty;
    barLegendText: ComponentFramework.PropertyTypes.StringProperty;
    chartTitleFontSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTextFontSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
}
export interface IOutputs {
    chartWidth?: number;
    chartHeight?: number;
    chartTitleText?: string;
    xAxisData?: string;
    lineValues?: string;
    barValues?: string;
    lineLegendText?: string;
    barLegendText?: string;
    chartTitleFontSize?: number;
    chartTextFontSize?: number;
}
