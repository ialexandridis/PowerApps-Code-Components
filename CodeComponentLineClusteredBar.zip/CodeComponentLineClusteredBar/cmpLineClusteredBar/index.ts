import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as d3 from 'd3';

export class cmpLineClusteredBar implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private _container: HTMLDivElement;
    private _width: number;
    private _height: number;
    //private _padding = { top: 50, right: 50, bottom: 200, left: 50 };
    private _xAxisData: string;
    private _lineValues: string;
    private _barValues: string;
    private _chartHeight: number;
    private _chartWidth: number;
    private _lineLegendText: string;
    private _barLegendText: string;
    private _chartTitle: string;
    private defaultColors = ['#BEB9DB', '#FFB55A'];
    private maxWidth: number;
    private testtest: number;
    private chartTextFontSize: number;
    private chartTitleFontSize: number;



    constructor() {
        this._width = 900; // Set the default width with padding
        this._height = 600; // Set the default height with padding
        this._xAxisData = "";
        this._lineValues = "";
        this._barValues = "";
        this._chartHeight = this._height;
        this._chartWidth = this._width;
        this._lineLegendText = ""; 
        this._barLegendText = ""; 
        this._chartTitle = "";
    }

    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this._container = container;
        this.updateView(context);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this._xAxisData = context.parameters.xAxisData.raw!;
        this._lineValues = context.parameters.lineValues.raw!;
        this._barValues = context.parameters.barValues.raw!;
        this._chartHeight = context.parameters.chartHeight.raw ? Number(context.parameters.chartHeight.raw) : this._height;
        this._chartWidth = context.parameters.chartWidth.raw ? Number(context.parameters.chartWidth.raw) : this._width;
        this._lineLegendText = context.parameters.lineLegendText.raw || '';
        this._barLegendText = context.parameters.barLegendText.raw || '';
        this._chartTitle = context.parameters.chartTitleText.raw || '';

        this.chartTextFontSize = context.parameters.chartTextFontSize.raw || 12;
        this.chartTitleFontSize = context.parameters.chartTitleFontSize.raw || 15;
    
        const xAxisArray = this._xAxisData.split(',');
        const lineValuesArray = this._lineValues.split(',').map(Number);
        const barValuesArray = this._barValues.split(',').map(Number);

        const colorScale = this.getColorScale(context);


        // Calculate the maximum length of xAxisData values
        const maxLabelLength = Math.max(...xAxisArray.map(label => this.getTextWidth(label)));


        //const _padding = { top: 50, right: 50, bottom: 120 + (maxLabelLength/this.maxWidth)*10 , left: 50 };
        const _padding = { top: 50 + this.chartTitleFontSize * 1.3, right: 50, bottom: 120 + this.testtest * (this.chartTextFontSize * 1.3)   , left: 70 };


        d3.select(this._container).selectAll('*').remove();
    
        const svg = d3.select(this._container)
            .append('svg')
            .attr('width', this._chartWidth)
            .attr('height', this._chartHeight);
    
        const xScale = d3.scaleBand()
            .domain(xAxisArray)
            .range([_padding.left, this._chartWidth - _padding.right])
            .padding(0.1);

        // Append X axis
        const xAxis = svg.append('g')
            .attr('transform', `translate(0, ${this._chartHeight - _padding.bottom})`)
            .style('font-size', `${this.chartTextFontSize}px`)
            .call(d3.axisBottom(xScale));

        // Select the x-axis tick labels and call wrapLabels on them
        xAxis.selectAll('.tick text')
            .call(this.wrapLabels, this.maxWidth);
        
        const yScale = d3.scaleLinear()
            .domain([0, d3.max([...barValuesArray, ...lineValuesArray])!])
            .range([this._chartHeight - _padding.bottom, _padding.top]);
        
        // Modify the Y-axis to use the formatNumber method
        const yAxis = d3.axisLeft(yScale).tickFormat(d => this.formatNumber(d));

        // Append Y axis with formatted values
        svg.append('g')
            .attr('transform', `translate(${_padding.left},0)`)
            .style('font-size', `${this.chartTextFontSize}px`)
            .call(yAxis);
    
        svg.selectAll('rect')
            .data(barValuesArray)
            .enter()
            .append('rect')
            .attr('x', (d, i) => xScale(xAxisArray[i])!)
            .attr('y', d => yScale(d))
            .attr('width', xScale.bandwidth())
            .attr('height', d => this._chartHeight - _padding.bottom - yScale(d))
            .attr('fill', colorScale('value1'));
    
        const line = d3.line<number>()
            .x((d, i) => xScale(xAxisArray[i])! + xScale.bandwidth() / 2)
            .y(d => yScale(d));
    
        svg.append('path')
            .datum(lineValuesArray)
            .attr('fill', 'none')
            .attr('stroke', colorScale('value2'))
            .attr('stroke-width', 5)
            .attr('d', line);

        

        //calculate the width for each label to wrap
        this.maxWidth = xScale.bandwidth();

        // Legends
        const lineLegendText = this._lineLegendText;
        const barLegendText = this._barLegendText;

        const textLength = (text: string) => text.length * 6; // Assuming 6px per character
        const textHeight = this.chartTextFontSize * 1.1; // Assuming 12px for text height

        const rectSize = 20;
        const legendSpacing = Math.max(textLength(lineLegendText), textLength(barLegendText));

        svg.append("text")
            .attr("x", this._chartWidth / 2)
            .attr("y", this._chartHeight - _padding.bottom / 4 - textHeight)
            .attr("text-anchor", "middle")
            .style("font-size", this.chartTextFontSize)
            .style("fill", colorScale('value2'))
            .text(lineLegendText);

        svg.append("rect")
            .attr("x", this._chartWidth / 2 - legendSpacing/2 - rectSize - 8)
            .attr("y", this._chartHeight - _padding.bottom / 4 - rectSize / 2 + 5 - textHeight)
            .attr("width", rectSize)
            .attr("height", 2)
            .style("fill", colorScale('value2'));

        svg.append("text")
            .attr("x", this._chartWidth / 2)
            .attr("y", this._chartHeight - _padding.bottom / 4 + textHeight)
            .attr("text-anchor", "middle")
            .style("font-size", this.chartTextFontSize)
            .style("fill", colorScale('value1'))
            .text(barLegendText);

        svg.append("rect")
            .attr("x", this._chartWidth / 2 - legendSpacing/2 - rectSize - 8)
            .attr("y", this._chartHeight - _padding.bottom / 4 - rectSize / 2 - 5 + textHeight)
            .attr("width", rectSize)
            .attr("height", rectSize)
            .style("fill", colorScale('value1'));

        // Inside your updateView method after xAxis.selectAll('.tick text').call(wrapLabels, this.maxWidth);
        this.testtest = this.wrapLabels(xAxis.selectAll('.tick text'), this.maxWidth);

        // Add title
        svg.append("text")
            .attr("x", this._chartWidth / 2)
            .attr("y", _padding.top / 2)
            .attr("text-anchor", "middle")
            .style("font-size", this.chartTitleFontSize)
            .text(this._chartTitle );

    }

    private wrapLabels(selection: d3.Selection<d3.BaseType, any, any, any>, maxWidth: number): number {
        let maxLines = 0;
    
        selection.each(function () {
            const text = d3.select(this);
            const words = text.text().split(/\s+/).reverse();
            let line: string[] = [];
            const lineHeight = 1.3;
            const y = text.attr('y');
            const dy = parseFloat(text.attr('dy') || '0');
            let tspan = text.text(null).append('tspan').attr('x', 0).attr('y', y).attr('dy', dy + 'em');
    
            let word = words.pop();
            let numberOfLines = 0;
    
            while (word) {
                line.push(word);
                tspan.text(line.join(' '));
                if (tspan.node()!.getComputedTextLength() > maxWidth) {
                    line.pop();
                    tspan.text(line.join(' '));
                    line = [word];
                    tspan = text
                        .append('tspan')
                        .attr('x', 0)
                        .attr('y', y)
                        .attr('dy', `${++numberOfLines * lineHeight + dy}em`)
                        .text(word);
                } else {
                    // Add space between words
                    line.push('');
                    tspan.text(line.join(' ')); // Update text with space
                }
                word = words.pop();
            }
    
            maxLines = Math.max(maxLines, numberOfLines);
            
        });
        return maxLines;
    }

    
    private getTextWidth(text: string): number {
        // Use a temporary span element to measure the width of the text
        const tempSpan = document.createElement('span');
        tempSpan.style.visibility = 'hidden';
        tempSpan.style.position = 'absolute';
        tempSpan.style.whiteSpace = 'nowrap';
        tempSpan.textContent = text;
    
        document.body.appendChild(tempSpan);
    
        const width = tempSpan.offsetWidth;
    
        document.body.removeChild(tempSpan);
    
        return width;
    }
    

    private formatNumber(n: number | { valueOf(): number }): string {
        const value = typeof n === 'number' ? n : n.valueOf();
        if (value >= 1e12) {
            return (value / 1e12).toFixed(1).replace(/\.0$/, '') + 'T';
        }
        if (value >= 1e9) {
            return (value / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
        }
        if (value >= 1e6) {
            return (value / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
        }
        if (value >= 1e3) {
            return (value / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
        }
        return value.toString();
    }

    private getColorScale(context: ComponentFramework.Context<IInputs>): d3.ScaleOrdinal<string, string> {
        let colorPalette: string[];



        // Use a switch case to select different color palettes based on user preferences 
        switch (context.parameters.ColorPalettePreference.raw) {
            case "colorSet1":
                colorPalette = [d3.schemeSet1[2], d3.schemeSet1[1], d3.schemeSet1[4]]; // Example colors for the second palette
                break;
            case "colorSet2":
                colorPalette = [d3.schemeSet2[6], d3.schemeSet2[1], d3.schemeSet2[3]];
                break;
            case "colorSet3":
                colorPalette = [d3.schemePastel1[0], d3.schemePastel1[3], d3.schemePastel1[4]];
                break;
            case "colorSet4":
                colorPalette = [d3.schemeDark2[0], d3.schemeDark2[2], d3.schemeDark2[5]];
                break;
            default:
                colorPalette = this.defaultColors;
        }

        return d3.scaleOrdinal<string>()
            .domain(['value1', 'value2', 'value3'])
            .range(colorPalette);
    }
    

    public getOutputs(): IOutputs {
        return {};
    }

    public destroy(): void {

    }
}
