/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    chartTitle: ComponentFramework.PropertyTypes.StringProperty;
    chartHeight: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartWidth: ComponentFramework.PropertyTypes.WholeNumberProperty;
    titleSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTextsSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    name: ComponentFramework.PropertyTypes.StringProperty;
    value: ComponentFramework.PropertyTypes.StringProperty;
    xs: ComponentFramework.PropertyTypes.StringProperty;
    ys: ComponentFramework.PropertyTypes.StringProperty;
    category: ComponentFramework.PropertyTypes.StringProperty;
    outlineBubbleColor: ComponentFramework.PropertyTypes.EnumProperty<"white" | "darkgray" | "Black">;
    outlineBubbleThickness: ComponentFramework.PropertyTypes.EnumProperty<"0" | "1" | "2" | "3" | "4" | "5">;
    ColorPalettePreference: ComponentFramework.PropertyTypes.EnumProperty<"colorSet1" | "colorSet2" | "colorSet3" | "colorSet4" | "colorSet5">;
}
export interface IOutputs {
    chartTitle?: string;
    chartHeight?: number;
    chartWidth?: number;
    titleSize?: number;
    chartTextsSize?: number;
    name?: string;
    value?: string;
    xs?: string;
    ys?: string;
    category?: string;
}
