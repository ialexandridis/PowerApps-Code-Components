import * as d3 from 'd3';
import { IInputs, IOutputs } from "./generated/ManifestTypes";

export class cmpLineChart implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private container: HTMLDivElement;
    private chartType: string;
    private lineChartLabels: string[];
    private line1Values: number[];
    private line2Values: number[];
    private line3Values: number[];
    private lineColor: string;
    private line2Color: string;
    private line3Color: string;
    private chartTitle: string;
    private chartHeight: number;
    private chartWidth: number;
    private lineThickness: number;
    private legendLabel1: string;
    private legendLabel2: string;
    private legendLabel3: string;
    private defaultColors = ['#0072BD', '#D95319', '#EDB120'];
    private titleSize: number;
    private axisTextSize: number;
    private maxWidth: number;
    private numberOfWrapLinesCreated: number;


    constructor() {
        this.chartType = 'line'; // Default chart type (line or bar)
        this.lineChartLabels = [];
        this.line1Values = [];
        this.line2Values = [];
        this.line3Values = [];
        this.lineColor = 'blue'; // Default color for the first line
        this.line2Color = 'red'; // Default color for the second line
        this.line3Color = 'green'; // Default color for the third line
        this.chartTitle = '';
        this.chartHeight = 400; // Default height
        this.chartWidth = 600; // Default width
        this.lineThickness = 3; // Default line thickness
        
    }

    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this.container = container;
        this.updateView(context);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        // Update properties
        
        if (context.parameters.chartTitle) {
            this.chartTitle = context.parameters.chartTitle.raw || '';
        }
        
        if (context.parameters.chartHeight) {
            this.chartHeight = context.parameters.chartHeight.raw || 400; // Default height
        }
        if (context.parameters.chartWidth) {
            this.chartWidth = context.parameters.chartWidth.raw || 600; // Default width
        }
        if (context.parameters.lineThickness) {
            this.lineThickness = context.parameters.lineThickness.raw || 3; // Default line thickness
        }


        if (context.parameters.axisTextSize) {
            this.axisTextSize = context.parameters.axisTextSize.raw || 13; // Default height
        }
        if (context.parameters.titleSize) {
            this.titleSize = context.parameters.titleSize.raw || 20; // Default line thickness
        }

        

        // Get the legend label values from input properties
        if (context.parameters.legendLabel1) {
            this.legendLabel1 = context.parameters.legendLabel1.raw || 'Legend 1';
        }
        if (context.parameters.legendLabel2) {
            this.legendLabel2 = context.parameters.legendLabel2.raw || ''; // Set empty label if not provided
        }
        if (context.parameters.legendLabel3) {
            this.legendLabel3 = context.parameters.legendLabel3.raw || ''; // Set empty label if not provided
        }

        // Update x-axis labels
        const lineChartLabelsString = (context.parameters.lineChartLabels.raw || '') as string;
        this.lineChartLabels = lineChartLabelsString.split(',').map(label => label.trim());
    
        // Update line chart data
        const line1Values = (context.parameters.line1Values.raw || '') as string;
        this.line1Values = line1Values.split(',').map(value => {
            const parsedValue = parseFloat(value);
            return isNaN(parsedValue) ? 0 : parsedValue;
        });
    
        // Retrieve line chart properties
        if (context.parameters.line2Values) {
            const line2ValuesString = context.parameters.line2Values.raw || '';
            this.line2Values = line2ValuesString.split(',').map(value => {
                const parsedValue = parseFloat(value);
                return isNaN(parsedValue) ? 0 : parsedValue;
            });
        } else {
            this.line2Values = [];
        }
    
    
        if (context.parameters.line3Values) {
            const line3ValuesString = context.parameters.line3Values.raw || '';
            this.line3Values = line3ValuesString.split(',').map(value => {
                const parsedValue = parseFloat(value);
                return isNaN(parsedValue) ? 0 : parsedValue;
            });
        } else {
            this.line3Values = [];
        }
    

        // Use the getColorScale function to get the appropriate color for each line
        const colorScale = this.getColorScale(context);

        // Update colors for the lines
        this.lineColor = colorScale('value1');
        this.line2Color = colorScale('value2');
        this.line3Color = colorScale('value3');
    
      
        // Draw the chart based on the updated data and properties
        this.drawChart(context);
    }
    

    private drawChart(context: ComponentFramework.Context<IInputs>): void {

        // Call the wrapLabels method and store the result in numberOfWrapLinesCreated
        this.numberOfWrapLinesCreated  = this.wrapLabels(d3.select(this.container).selectAll('.x-axis text'),  this.maxWidth);
        d3.select(this.container).selectAll('*').remove();

        // Adjust the left margin based on the maximum width of the y-axis labels
        const margin = { top: 45 + this.titleSize, right: 30, bottom: 120 + this.calculateNewWidth() + (this.numberOfWrapLinesCreated * (this.axisTextSize * 1.3)) , left: 50  }; // Adjust the constant value as needed
    
        const width = this.chartWidth - margin.left - margin.right;
        const height = this.chartHeight - margin.top - margin.bottom;


        //calculate the width for each label to wrap
        this.maxWidth = width/this.lineChartLabels.length - 20 ;
    
        const colorScale = this.getColorScale(context);
    
        const svg = d3.select(this.container)
            .append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);
    
        // Add title
        svg.append('text')
            .attr('x', width / 2)
            .attr('y', -margin.top / 2)
            .attr('text-anchor', 'middle')
            .style('font-size', this.titleSize)
            .text(this.chartTitle);
    
        // Calculate maximum value among all lines for y-axis domain
        const maxValues = [...this.line1Values, ...this.line2Values, ...this.line3Values];
        const y = d3.scaleLinear()
            .domain([0, d3.max(maxValues) || 0])
            .nice()
            .range([height, 0]);
    
        // Add X axis
        const x = d3.scalePoint()
            .domain(this.lineChartLabels)
            .range([0, width])
            .padding(0.5);
    
        svg.append('g')
            .attr('class', 'x-axis') // Add class for the x-axis
            .attr('transform', `translate(0, ${height})`)
            .call(d3.axisBottom(x))
            .selectAll('text')
            .style('font-size', this.axisTextSize) // Adjust the font size as needed
            .call(this.wrapLabels, this.maxWidth);
    
        // Add Y axis
        svg.append('g')
            .call(d3.axisLeft(y).tickFormat((d: any) => this.formatNumber(d)))
            .selectAll('text')
            .style('font-size', this.axisTextSize); // Adjust the font size as needed
    
    
        // Define the line function
        const line = d3.line<number>()
            .x((d, i) => x(this.lineChartLabels[i]) || 0)
            .y(d => y(d));
    
        // Add the first line (existing line)
        svg.append('path')
            .datum(this.line1Values)
            .attr('fill', 'none')
            .attr('stroke', colorScale('value1'))
            .attr('stroke-width', this.lineThickness)
            .attr('d', line);
    
        // Add the second line (new line)
        svg.append('path')
            .datum(this.line2Values)
            .attr('fill', 'none')
            .attr('stroke', colorScale('value2'))
            .attr('stroke-width', this.lineThickness)
            .attr('d', line);
    
        // Add the third line (new line)
        svg.append('path')
            .datum(this.line3Values)
            .attr('fill', 'none')
            .attr('stroke', colorScale('value3'))
            .attr('stroke-width', this.lineThickness)
            .attr('d', line);

        
        // Add a group element to hold the legends
        const legendGroup = svg.append('g')
            .attr('transform', `translate(0, ${height + 40})`); // Adjust the vertical position as needed
    
        // Add legends with padding
        const legendNames = [this.legendLabel1, this.legendLabel2, this.legendLabel3];
        const legendColors = [this.lineColor, this.line2Color, this.line3Color];

        
        const verticalSpacing = this.axisTextSize *1.4; // Adjust the spacing as needed
    
        legendNames.forEach((name, index) => {
            const legendX = 0; // Adjust the horizontal position as needed
            const legendY = index * verticalSpacing + 10; // Adjust the vertical position based on the index
    
            legendGroup.append('rect')
                .attr('x', legendX)
                .attr('y', legendY + 5 + (this.numberOfWrapLinesCreated * (this.axisTextSize * 1.1)))
                .attr('width', 15)
                .attr('height', 5)
                .style('fill', legendColors[index]);
    
            legendGroup.append('text')
                .attr('x', legendX + 20)
                .attr('y', legendY + 12 + (this.numberOfWrapLinesCreated * (this.axisTextSize * 1.1)))
                .text(name);
        });
    
        legendGroup.selectAll('text')
            .attr('font-size', this.axisTextSize); // Adjust the font size as needed
    }

    private calculateNewWidth(): number {
        if (this.axisTextSize < 23) {
            return 0;
        } else if (this.axisTextSize > 23 && this.axisTextSize <= 27) {
            return this.axisTextSize * 0.5;
        } else if (this.axisTextSize > 27 && this.axisTextSize <= 30) {
            return this.axisTextSize * 0.9;
        } else if (this.axisTextSize > 30) {
            return this.axisTextSize * 1.3;
        }
        return 0; // Default value if none of the conditions are met
    }

    private formatNumber(n: number | { valueOf(): number }): string {
        const value = typeof n === 'number' ? n : n.valueOf();
        if (value >= 1e12) {
            return (value / 1e12).toFixed(1).replace(/\.0$/, '') + 'T';
        }
        if (value >= 1e9) {
            return (value / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
        }
        if (value >= 1e6) {
            return (value / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
        }
        if (value >= 1e3) {
            return (value / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
        }
        return value.toString();
    }
    
    private wrapLabels(selection: d3.Selection<d3.BaseType, any, any, any>, maxWidth: number): number {
        let maxLines = 0;
    
        selection.each(function () {
            const text = d3.select(this);
            const words = text.text().split(/\s+/).reverse();
            let line: string[] = [];
            const lineHeight = 1.3;
            const y = text.attr('y');
            const dy = parseFloat(text.attr('dy') || '0');
            let tspan = text.text(null).append('tspan').attr('x', 0).attr('y', y).attr('dy', dy + 'em');
    
            let word = words.pop();
            let numberOfLines = 0;
    
            while (word) {
                line.push(word);
                tspan.text(line.join(' '));
                if (tspan.node()!.getComputedTextLength() > maxWidth) {
                    line.pop();
                    tspan.text(line.join(' '));
                    line = [word];
                    tspan = text
                        .append('tspan')
                        .attr('x', 0)
                        .attr('y', y)
                        .attr('dy', ++numberOfLines * lineHeight + dy + 'em')
                        .text(word);
                } else {
                    // Add space between words
                    line.push('');
                }
                word = words.pop();
            }
    
            maxLines = Math.max(maxLines, numberOfLines);

        });
    
        return maxLines;
    }
    

    
    

    private getColorScale(context: ComponentFramework.Context<IInputs>): d3.ScaleOrdinal<string, string> {
        let colorPalette: string[];



        // Use a switch case to select different color palettes based on user preferences 
        switch (context.parameters.ColorPalettePreference.raw) {
            case "colorSet1":
                colorPalette = [d3.schemeSet1[2], d3.schemeSet1[1], d3.schemeSet1[4]]; // Example colors for the second palette
                break;
            case "colorSet2":
                colorPalette = [d3.schemeSet2[6], d3.schemeSet2[1], d3.schemeSet2[3]];
                break;
            case "colorSet3":
                colorPalette = [d3.schemePastel1[0], d3.schemePastel1[3], d3.schemePastel1[4]];
                break;
            case "colorSet4":
                colorPalette = [d3.schemeDark2[0], d3.schemeDark2[2], d3.schemeDark2[5]];
                break;
            default:
                colorPalette = this.defaultColors;
        }

        return d3.scaleOrdinal<string>()
            .domain(['value1', 'value2', 'value3'])
            .range(colorPalette);
    }
    

    public getOutputs(): IOutputs {
        return {};
    }

    public destroy(): void {
        // Cleanup if needed
    }
}
