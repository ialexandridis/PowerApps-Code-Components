/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    ColorPalettePreference: ComponentFramework.PropertyTypes.EnumProperty<"colorSet1" | "colorSet2" | "colorSet3" | "colorSet4" | "colorSet5">;
    chartHeight: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartWidth: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTitle: ComponentFramework.PropertyTypes.StringProperty;
    lineChartLabels: ComponentFramework.PropertyTypes.StringProperty;
    line1Values: ComponentFramework.PropertyTypes.StringProperty;
    line2Values: ComponentFramework.PropertyTypes.StringProperty;
    line3Values: ComponentFramework.PropertyTypes.StringProperty;
    lineThickness: ComponentFramework.PropertyTypes.DecimalNumberProperty;
    legendLabel1: ComponentFramework.PropertyTypes.StringProperty;
    legendLabel2: ComponentFramework.PropertyTypes.StringProperty;
    legendLabel3: ComponentFramework.PropertyTypes.StringProperty;
    titleSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    axisTextSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
}
export interface IOutputs {
    chartHeight?: number;
    chartWidth?: number;
    chartTitle?: string;
    lineThickness?: number;
    titleSize?: number;
    axisTextSize?: number;
}
