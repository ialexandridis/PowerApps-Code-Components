// Import necessary modules
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as d3 from 'd3';

// Define the class cmpWaterfallChart implementing the necessary interfaces
export class cmpWaterfallChart implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    // Define private variables
    private _container: HTMLDivElement; // Container for the chart
    private biggestSum: number; // Initialize the variable to store the biggest output
    private defaultColors = ['steelblue'];
    // Constructor
    constructor() {
    }

    // Initialization method for the component
    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this._container = container; // Set the container
    }

    // Method to update the view based on the context
    public updateView(context: ComponentFramework.Context<IInputs>): void {

        // Refresh the chart
        d3.select(this._container).selectAll('*').remove();

        // Extract necessary parameters from context
        const chartWidth = context.parameters.chartWidth.raw || 500;
        const chartHeight = context.parameters.chartHeight.raw || 300;
        const initialValue = context.parameters.initialValue.raw || 5000;
        const labelsProperty = context.parameters.labelsProperty.raw;
        const valuesProperty = context.parameters.valuesProperty.raw;
        const i_f_BarColors = context.parameters.i_f_BarColors.raw || '#5BBCD6';
        const chartFontSize = context.parameters.chartFontSize.raw || 14;
        const chartTitleFontSize = context.parameters.chartTitleFontSize.raw || 20;
        const chartBarValuesFontSize = context.parameters.chartBarValuesFontSize.raw || 20;

        const chartTitle = context.parameters.chartTitle.raw || '';
        const currencySymbol = context.parameters.currencySymbol.raw || '$';

        // Get the color scale based on the selected palette
        const colorScale = this.getColorScale(context);


        // Set up margins for the chart
        const margin = { top: 70 + chartFontSize, right: 50 , bottom: 50, left: 50 + chartFontSize*1.5};
        const width = chartWidth - margin.left - margin.right; // Adjust the width value here
        const height = chartHeight - margin.top - margin.bottom; // Adjust the height value here

        // Initialize data with the initial value
        let data: { label: string; value: number }[] = [
            { label: 'Initial', value: initialValue }
        ];

        // Check if properties exist and process them
        if (labelsProperty && valuesProperty) {
            const labels = labelsProperty.split(',');
            const values = valuesProperty.split(',');

            // Check if labels and values have the same length
            if (labels.length === values.length) {
                for (let i = 0; i < labels.length; i++) {
                    const label = labels[i];
                    const value = +values[i]; // Convert string to number
                    data.push({ label, value }); // Push label-value pair to data
                }
            } 
        }



        // Calculate the sum of all values
        const sum = d3.sum(data, (d) => d.value);

        // Add the final total to the data array
        data.push({ label: 'Final', value: sum });


        let runningSum = 0; // Initialize the running sum
        let lowestSum = 0; // Initialize the lowest sum
        this.biggestSum = 0;
        data.forEach((d) => {
            if (d.label !== 'Final') {
                runningSum += d.value; // Add the current value to the running sum

                if (runningSum > this.biggestSum) {
                    this.biggestSum = runningSum; // Update the biggest sum if necessary
                }

                if (runningSum < lowestSum) {
                    lowestSum = runningSum; // Update the lowest sum if necessary
                }
            }
        });


        // Adjust the y-axis domain based on the comparison
        const y = d3.scaleLinear().domain([lowestSum, this.biggestSum]).range([height, 0]);

        // Set up x-axis scaling
        const x = d3.scaleBand().domain(data.map((d) => d.label)).range([0, width]).padding(0.1);

        
        // Create SVG element for the chart
        const svg = d3.select(this._container)
            .append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .append('g')
            .attr('font-size',chartFontSize)
            .attr('transform', `translate(${margin.left},${margin.top})`);

        // Initialize variables for positioning and height calculations
        let initialYPosition = y(0);
        let currentYPosition = initialYPosition;
        let previousValue = 0;
        let previousBarHeight = 0;

        // Draw rectangles for each data point
        svg
            .selectAll('rect')
            .data(data)
            .enter()
            .append('rect')
            .attr('x', (d) => x(d.label)!)
            .attr('y', (d) => {
                // Determine the y-position based on the data label
                if (d.label  === 'Final') {
                    if(sum<0){
                        return y(Math.max(0, d.value)); // Set the y-position to 0 if the sum is negative
                    }else{
                        return y(d.value);
                    }
                } else {  
                    const barHeight = Math.abs(y(0) - y(d.value));
                    let position;
                    if (previousValue < 0 && d.value < 0) {
                        position = currentYPosition + previousBarHeight ;
                    } else if (previousValue < 0 && d.value > 0) {
                        position = currentYPosition - (barHeight-previousBarHeight);
                    } else {
                        position = d.value > 0 ? currentYPosition - barHeight : currentYPosition;
                    }
                    currentYPosition = position;
                    previousValue = d.value;
                    previousBarHeight = barHeight; // Update previousBarHeight

                    // Add the text for the value within each bar
                    svg
                        .append('text')
                        //.text(`${currencySymbol + this.formatNumber(d.value)}`)
                        .text(`${(d.value < 0 ? '-' : '') + currencySymbol + this.formatNumber(Math.abs(d.value))}`)
                        .attr('x', x(d.label)! + x.bandwidth() / 2)
                        .attr('y', d.value >= 0 ? position - 5 : position + barHeight + chartBarValuesFontSize ) // Adjust the positioning for negative values
                        .attr('text-anchor', 'middle')
                        .attr('font-size',chartBarValuesFontSize)
                        .attr('fill', 'black')
                        .attr('font-weight', () => (d.label === 'Initial' || d.label === 'Final') ? 'bold' : 'normal'); // Set font-weight directly
                        

                    // Add the text for the sum on top of the final bar
                    svg
                        .append('text') 
                        //.text(`${currencySymbol + this.formatNumber(sum)}`)
                        .text(`${(sum < 0 ? '-' : '') + currencySymbol + this.formatNumber(Math.abs(sum))}`)
                        .attr('x', x('Final')! + x.bandwidth() / 2)
                        //.attr('y', y(sum) - 10) // Adjust the position of the text
                        .attr('y', sum < 0 ? y(sum) + 5 + chartFontSize : y(sum) - 10) // Adjust the position of the text
                        .attr('text-anchor', 'middle')
                        .attr('font-size',chartBarValuesFontSize)
                        .attr('fill', 'black');

                    return position;
                }
            })
            .attr('width', x.bandwidth())
            .attr('height', (d) => Math.abs(y(0) - y(d.value)))

            .attr('fill', (d) => {
                // Set colors for different bars
                if (d.label === 'Initial') {
                    return colorScale('Initial') ; // Set color for the 'Initial' bar
                } else if (d.label === 'Final') {
                    return colorScale('Final'); // Set color for the 'Final' bar
                } else {
                    return d.value > 0 ? '#65DDA1' : '#FF8D8D'; // Set colors for positive and negative values
                }
            })
            .attr('font-weight', (d) => (d.label === 'Initial' || d.label === 'Final') ? 'bold' : 'normal'); // Set font-weight directly


        // Set the final bar's y position to 0
        svg.select('rect:last-child').attr('y', 0);

        // Append x and y axes to the chart
        // svg.append('g').attr('transform', `translate(0,${height})`).call(d3.axisBottom(x)); // X-axis
        svg.append('g')
            .attr('transform', `translate(0,${y(0)})`).call(d3.axisBottom(x)) // X-axis
            .selectAll('text')
            .attr('font-size', chartFontSize) // Set font size for x-axis labels
            .call(this.wrapLabels, x.bandwidth()); // Call wrapLabels to handle word wrapping

            
        svg.append('g')
            //.call(d3.axisLeft(y).tickFormat(d => currencySymbol + this.formatNumber(d))) // Y-axis
            .call(d3.axisLeft(y).tickFormat((d) => {
                return (d.valueOf() < 0 ? '-' : '') + currencySymbol + this.formatNumber(Math.abs(d.valueOf()));
            })) // Y-axis
            .selectAll('text')
            .attr('font-size', chartFontSize); // Set font size for y-axis labels
            
        // Append title to the chart
        svg.append('text')
            .attr('x', width / 2)
            .attr('y', -margin.top / 2)
            .attr('text-anchor', 'middle')
            .attr('font-size', chartTitleFontSize) // Adjust font size for the title
            .text(chartTitle);


    }

    // Function to format numbers
    private formatNumber(n: number | { valueOf(): number }): string {
        const value = typeof n === 'number' ? n : n.valueOf();
        const sign = Math.sign(value); // Get the sign of the value

        // Format the absolute value of the number
        let formattedValue = '';
        if (Math.abs(value) >= 1e12) {
            formattedValue = (Math.abs(value) / 1e12).toFixed(1).replace(/\.0$/, '') + 'T';
        } else if (Math.abs(value) >= 1e9) {
            formattedValue = (Math.abs(value) / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
        } else if (Math.abs(value) >= 1e6) {
            formattedValue = (Math.abs(value) / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
        } else if (Math.abs(value) >= 1e3) {
            formattedValue = (Math.abs(value) / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
        } else {
            formattedValue = Math.abs(value).toString();
        }

        // Include the sign in the formatted value
        return (sign === -1 ? '-' : '') + formattedValue;
    }

    // Method to get outputs
    public getOutputs(): IOutputs {
        return {};
    }

    // Method to handle component destruction
    public destroy(): void {
        // Add code to cleanup control if necessary
    }


    private wrapLabels(selection: d3.Selection<d3.BaseType, any, any, any>, maxWidth: number): number {
        let maxLines = 0;
    
        selection.each(function () {
            const text = d3.select(this);
            const words = text.text().split(/\s+/).reverse();
            let line: string[] = [];
            const lineHeight = 1.3;
            const y = text.attr('y');
            const dy = parseFloat(text.attr('dy') || '0');
            let tspan = text.text(null).append('tspan').attr('x', 0).attr('y', y).attr('dy', dy + 'em');
    
            let word = words.pop();
            let numberOfLines = 0;
    
            while (word) {
                line.push(word);
                tspan.text(line.join(' '));
                if (tspan.node()!.getComputedTextLength() > maxWidth) {
                    line.pop();
                    tspan.text(line.join(' '));
                    line = [word];
                    tspan = text
                        .append('tspan')
                        .attr('x', 0)
                        .attr('y', y)
                        .attr('dy', `${++numberOfLines * lineHeight + dy}em`)
                        .text(word);
                } else {
                    // Add space between words
                    line.push('');
                    tspan.text(line.join(' ')); // Update text with space
                }
                word = words.pop();
            }
    
            maxLines = Math.max(maxLines, numberOfLines);
        });
    
        return maxLines;
    }
    

    private colorPalettes: { [key: string]: string[] } = {
        Light_Green: ['#94BC5D'],
        Yellow: ['#F4D470'],
        Purple: ['#A48BC1'],
        Blue_Gray: ['#5C96A5'],
        Gold: ['#F5C767'],
        Dark_Grayish_Purple: ['#76677B'],
        Pale_Yellow: ['#DBD588'],
        Pink: ['#DC9BB0'],
        Light_Blue: ['#88C9DB'],
        Teal: ['#8DD3C7'],
        Cream: ['#FFFFB3'],
        Steel_Blue: ['#80B1D3'],
        // ... Add more palettes as needed
    };

    private getColorScale(context: ComponentFramework.Context<IInputs>): d3.ScaleOrdinal<string, string> {
        const paletteKey = context.parameters.ColorPalettePreference.raw;
        const colorPalette = this.colorPalettes[paletteKey as keyof typeof this.colorPalettes] || this.defaultColors;
    
        return d3.scaleOrdinal<string>()
            .domain(['value1'])
            .range(colorPalette);
    }
}