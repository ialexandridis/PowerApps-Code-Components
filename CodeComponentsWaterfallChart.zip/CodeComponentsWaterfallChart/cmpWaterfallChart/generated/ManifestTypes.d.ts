/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    labelsProperty: ComponentFramework.PropertyTypes.StringProperty;
    valuesProperty: ComponentFramework.PropertyTypes.StringProperty;
    chartWidth: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartHeight: ComponentFramework.PropertyTypes.WholeNumberProperty;
    initialValue: ComponentFramework.PropertyTypes.WholeNumberProperty;
    i_f_BarColors: ComponentFramework.PropertyTypes.StringProperty;
    chartFontSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartBarValuesFontSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTitleFontSize: ComponentFramework.PropertyTypes.WholeNumberProperty;
    chartTitle: ComponentFramework.PropertyTypes.StringProperty;
    currencySymbol: ComponentFramework.PropertyTypes.StringProperty;
    ColorPalettePreference: ComponentFramework.PropertyTypes.EnumProperty<"Light_Green" | "Yellow" | "Purple" | "Blue_Gray" | "Gold" | "Dark_Grayish_Purple" | "Pale_Yellow" | "Pink" | "Light_Blue" | "Teal" | "Cream" | "Steel_Blue">;
}
export interface IOutputs {
    labelsProperty?: string;
    valuesProperty?: string;
    chartWidth?: number;
    chartHeight?: number;
    initialValue?: number;
    i_f_BarColors?: string;
    chartFontSize?: number;
    chartBarValuesFontSize?: number;
    chartTitleFontSize?: number;
    chartTitle?: string;
    currencySymbol?: string;
}
